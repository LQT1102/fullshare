<template>
  <div id="app">
    
    <div v-if="step==0">
      <div class="step0"><TempCamera /></div>
    </div>
    <div v-if="step==1">
      <div>Step 1</div>
      <DemoCameraFace/>
    </div>
    <button @click="handleSwitch">Switch</button>
  </div>
</template>

<script>
import DemoCameraFace from './components/CameraFace.vue';
import TempCamera from "./components/TempCamera.vue";

function handleSwitch(){
  if(this.step == 0){
    this.step = 1;
  }else{
    this.step = 0;
  }
}

export default {
  name: 'App',
  components: {
    DemoCameraFace,
    TempCamera,
},
  data(){
    return {
      step: 1
    }
  },
  methods: {
    handleSwitch
  }
}
</script>

<style scoped>

.step0{
}

body{
  overflow: hidden;
}
*{
  padding: 0px;
  margin: 0px;
}

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  min-height: 100vh;
}
</style>
