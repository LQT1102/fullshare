<template>
  <div style="width: 100%; height: 100%;">
    <div
      style="width: 100%; height: 100%; position: relative;"
      id="liveView"
      class="videoView"
    >
      <video id="webcam" autoplay playsinline class="webcam" ></video>
      <div class="overlay">
        <div class="overlay-transparent overlay-top" :style="`height: ${frameConfig.top}px`"></div>
        <div style="display: flex;">
          <div class="overlay-transparent overlay-left" :style="`width: ${frameConfig.px}px`"></div>
          <div class="frame-content" id="frame-content" :style="`height: ${frameConfig.height}px`"></div>
          <div class="overlay-transparent overlay-right" :style="`width: ${frameConfig.px}px`"></div>
        </div>
        <div class="overlay-transparent overlay-bottom"></div>
      </div>
      <canvas id="cv2"></canvas>
      <canvas id="cv1"></canvas>
      <button style="position: absolute; bottom: 0px; left: 0px;" @click="handleTakeScreenshot">Take screenshot</button>
    </div>
  </div>
</template>

<script>

/**
 * Config vị trí của khung chứa đối tượng cần chụp
 */
const FRAME_CONFIG = {
  top: 86,
  height: 255,
  px: 8
}

export default {
  name: "DemoCamera",
  props: {},
  mounted() {
    this.startApp();
  },
  data() {
    return {
      video: null,
      liveView: null,
      hasGetUserMedia: false,
      faceDetector: null,
      runningMode: "IMAGE",
      lastVideoTime: -1,
      children: [],
      warnningText: "",
      frameConfig: FRAME_CONFIG
    };
  },
  methods: {
    getUserMedia() {
      return !!navigator.mediaDevices?.getUserMedia;
    },

    async startApp() {
      await navigator.mediaDevices.getUserMedia({ video: true });
      this.video = document.getElementById("webcam");
      this.liveView = document.getElementById("liveView");
      if (!this.getUserMedia()) {
        console.log("Máy không cho bật camera");
        return;
      }

      // yêu cầu sử dụng webcame
      await this.enableCamera();
    },

    async enableCamera() {
      const me = this;
      //Kiểm tra ưu tiên dùng cam trước
      const devices = await navigator.mediaDevices.enumerateDevices();

      var cameras = devices.filter(function (device) {
        return device.kind === 'videoinput';
      });

      if(!cameras?.length){
        console.log("Không có camera");
        return
      }

       var rearCamera = cameras.find(function (device) {
        return !device.label.toLowerCase().includes('front');
      }) || cameras[0];

      navigator.mediaDevices
        .getUserMedia({
          video: { deviceId: { exact: rearCamera?.deviceId },}
        })
        .then((stream) => {
          me.video.srcObject = stream;
        })
        .catch((e) => {
          console.log(e);
        });
    },
    handleTakeScreenshot(){
      const me = this;
      var canvasElement = document.getElementById('cv1');
      const player = document.getElementById("webcam");
      // Lấy chiều rộng và chiều cao của video
      var videoWidth = me.video.videoWidth;
      var videoHeight = me.video.videoHeight;

      // Đặt kích thước của canvas bằng kích thước của video
      canvasElement.width = videoWidth;
      canvasElement.height = videoHeight;

      // Vẽ video lên canvas
      var canvasContext = canvasElement.getContext('2d');

      canvasContext.drawImage(me.video, 0, 0, videoWidth,videoHeight);
      // canvasContext.drawImage(me.video, 8, 86, videoWidth,videoHeight);

      // Tạo một phần tử <img> để hiển thị ảnh đã chụp
      var capturedImageElement = document.createElement('img');
      capturedImageElement.src = canvasElement.toDataURL('image/png');
      capturedImageElement.width = player.offsetWidth;
      capturedImageElement.height = player.offsetHeight;
      // capturedImageElement.height = videoHeight;
      document.body.appendChild(capturedImageElement);

      // canvasElement.width = videoWidth;
      // canvasElement.height = videoHeight;
      // canvasContext.drawImage(capturedImageElement, 0, 0, videoWidth,videoHeight);

    //     // //Cắt ảnh theo đúng phần box
    //   const canvas = document.getElementById('cv2');

    //   const ctx = canvas.getContext('2d');
    //   // Thiết lập kích thước của canvas theo kích thước cần cắt
    //   canvas.width = capturedImageElement.width - this.frameConfig.px * 2;
    //   canvas.height = this.frameConfig.height;
    //     alert(JSON.stringify(this.frameConfig))
    //   // Vẽ phần cắt từ hình ảnh gốc lên canvas
    //   ctx.drawImage(capturedImageElement, this.frameConfig.px, this.frameConfig.top, 100,  100);

    // // Tạo một đối tượng hình ảnh mới từ phần cắt

    // var capturedImageElement2 = document.createElement('img');
    //     capturedImageElement2.src = canvas.toDataURL('image/png');
    //     capturedImageElement2.width = capturedImageElement.width - this.frameConfig.px * 2;
      
    //   capturedImageElement2.height = this.frameConfig.height;
      
    //     document.body.appendChild(capturedImageElement2);
      

      var formData = new FormData();
      formData.append('photo', canvasElement.toDataURL('image/png'));

      console.log(formData);
    }
  },
};
</script>


<style  scoped>

.webcam{
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
}
.overlay{
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;

}

.overlay-top{
  width: 100%;
  height: 86px;
}

.overlay-bottom{
  flex: 1;
  min-height: 0px;
  width: 100%
}

.overlay-left{
  width: 8px;
}

.overlay-right{
  width: 8px;
}

.frame-content{
  flex: 1;
  min-width: 0px;
  height: 225px;
}

.overlay-transparent{
  background-color: #291b35;
  opacity: 0.5;
}
</style>
