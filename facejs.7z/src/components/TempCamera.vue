<template>
<div class="capturer-wrapper">
  <div class="capturer" ref="capturerRef" :style="{ height: `${cameraHeight}px` }">
    <video v-show="mode === 'VIDEO'" ref="videoRef" @click="toggleImage" playsinline="true">
    Video not available
    </video>
  <div
    class="overlay top"
    :style="{
    left: `${cameraPaddingX}px`,
    right: `${cameraPaddingX}px`,
    height: `${Math.min(cameraPaddingY, cameraHeight)}px`}"></div>
  <div class="overlay right" :style="{ width: `${cameraPaddingX}px` }"></div>
  <div
    class="overlay bottom"
    :style="{
      left: `${cameraPaddingX}px`,
      right: `${cameraPaddingX}px`,
      height: `${Math.min(cameraPaddingY, cameraHeight)}px`,
    }"
  ></div>
  <div class="overlay left" :style="{ width: `${cameraPaddingX}px` }"></div>
  <img
    v-show="mode === 'IMAGE'"
    ref="imageRef"
    alt="Image not available"
    :style="{
      left: `${cameraPaddingX}px`,
      right: `${cameraPaddingX}px`,
      top: `${cameraPaddingY}px`,
      bottom: `${cameraPaddingY}px`,
    }"
    @click="toggleImage"/>
  </div>
  <div class="capturer-controller"></div>
</div>
</template>

<script>

// function base64ToBuffer(base64){
//   // Chuyển đổi base64 thành ArrayBuffer
//   const binaryString = window.atob(base64.split(",")[1]);
//   const length = binaryString.length;
//   const bytes = new Uint8Array(length);
//   for (let i = 0; i < length; i++) {
//     bytes[i] = binaryString.charCodeAt(i);
//   }
//   const buffer = bytes.buffer;
//   return buffer
// }

// const testCallApi = (b64String) => {
//    const imgBuffer = base64ToBuffer(b64String);
//         const imageBackBase64 = imgBuffer;

//         const requestHeaders = {
//           'request-id': 'dcb0e6f1-d2eb-4ec8-b393-4bacc74229d9',
//           'api-key': 'e457a4ed46894bb7bd332f099cdcd110'
//         };

//         const fileFront = new File([imgBuffer], "fileFront.png", { type: "image/png" });

//         const fileBack = new File([imageBackBase64], "fileBack.png", { type: "image/png" });
//         // Tạo FormData và thêm dữ liệu hình ảnh
//         const formData = new FormData();
//         formData.append('image', fileFront, fileFront.name );
//         formData.append('image_back', fileBack, fileBack.name);
//         formData.append('params', JSON.stringify({ quality: false, liveness: false, mrz: false, qr: false, split_location: false }));

//         // Tạo yêu cầu POST
//         fetch('https://test-aiservice.misa.com.vn/ekyc/v2/cards/ocr', {
//           method: 'POST',
//           headers: requestHeaders,
//           body: formData
//         })
//           .then(response => response.json())
//           .then(data => {
//             alert(JSON.stringify(data))
//             console.log(data);
//           })
//           .catch(error => {
//             alert(error + "");
//             alert(JSON.stringify())
//             console.log(error);
//           });
// }
/**
 * Output kích thước của ảnh khi chụp xong
 */
const OUTPUT_IMAGE_CONFIG = {
  WIDTH: 640,
  HEIGHT: 480,
};
export default {
  name: "EkycTakeIdentityDoc",
  async mounted() {
    try {
        // testCallApi("");
      this.$refs.videoRef.addEventListener("canplay", this.onCanPlay, false);
      await navigator.mediaDevices.getUserMedia({ video: true });

      //Kiểm tra ưu tiên dùng cam trước
      const devices = await navigator.mediaDevices.enumerateDevices();

      var cameras = devices.filter(function (device) {
        return device.kind === "videoinput";
      });

      if (!cameras?.length) {
        console.log("Không có camera");
        alert("Đã xảy ra lỗi, không tìm thấy camera.");
        return;
      }

      const stream = await window.navigator.mediaDevices.getUserMedia({
        video: { facingMode: { exact: "environment" } },
        audio: false,
      });

      this.$refs.videoRef.srcObject = stream;
      this.$refs.videoRef.play();
    } catch (error) {
      console.error("" + error);
      alert("Đã xảy ra lỗi !");
    }
  },
  destroyed() {
    this.$refs.videoRef.removeEventListener("canplay", this.onCanPlay, false);
  },
  data() {
    return {
      mode: "VIDEO",
      // tỉ lệ của vùng sáng (thẻ CCCD)
      windowRatio: 4 / 3,
      // khoảng padding 2 bên vùng sáng
      cameraPaddingX: 8,
      // chiều rộng vùng camera
      cameraWidth: 0,
      // chiều cao vùng camera
      cameraHeight: 0,
    };
  },
  computed: {
    cameraPaddingY() {
      return Math.round((this.cameraHeight - this.windowHeight) / 2);
    },
    windowWidth() {
      return this.cameraWidth - 2 * this.cameraPaddingX;
    },
    windowHeight() {
      return Math.round(this.windowWidth / this.windowRatio);
    },
  },
  methods: {
    onCanPlay() {
      this.cameraWidth = this.$refs.capturerRef.clientWidth;
      let videoRatio =
        this.$refs.videoRef.videoWidth / this.$refs.videoRef.videoHeight;
      // this.cameraHeight = Math.round(this.cameraWidth / videoRatio);
      this.cameraHeight = Math.round(this.cameraWidth / videoRatio);
    },
    getUserMedia() {
      return !!navigator.mediaDevices?.getUserMedia;
    },
    toggleImage() {
      if (this.mode === "VIDEO") {
        let videoWidth = this.$refs.videoRef.videoWidth;
        let videoHeight = this.$refs.videoRef.videoHeight;
        let canvas = document.createElement("canvas");
        canvas.width = OUTPUT_IMAGE_CONFIG.WIDTH;
        canvas.height = OUTPUT_IMAGE_CONFIG.HEIGHT;
        let context = canvas.getContext("2d");
        context.drawImage(
          this.$refs.videoRef,
          (this.cameraPaddingX * videoWidth) / this.cameraWidth,
          (this.cameraPaddingY * videoHeight) / this.cameraHeight,
          (this.windowWidth * videoWidth) / this.cameraWidth,
          (this.windowHeight * videoHeight) / this.cameraHeight,
          0,
          0,
          OUTPUT_IMAGE_CONFIG.WIDTH,
          OUTPUT_IMAGE_CONFIG.HEIGHT,
        );
        let src = canvas.toDataURL("image/png");
        this.$refs.imageRef.setAttribute("src", src);
        this.mode = "IMAGE";
       
      } else {
        this.mode = "VIDEO";
      }
    },
  },
};
</script>

<style scoped>
.capturer-wrapper {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  display: flex;
  flex-direction: column;
}

.capturer {
  position: relative;
}

.capturer-controller {
  flex: 1;
  min-width: 0px;
  width: 100%;
  background-color: #292b35;
}

.overlay {
  background-color: #292b35;
  opacity: 0.56;
}
.overlay.top {
  position: absolute;
  top: 0;
}
.overlay.right {
  position: absolute;
  right: 0;
  height: 100%;
}
.overlay.bottom {
  position: absolute;
  bottom: 0;
}
.overlay.left {
  position: absolute;
  left: 0;
  height: 100%;
}

video {
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
}

img {
  position: absolute;
}

@media (min-width: 768px) {
  .capturer-wrapper {
  }

  .capturer {
    position: relative;
    margin: 0 auto;
    width: 570px;
    min-height: 570px;
  }
}
</style>