<template>
<div class="container">
  <div class="overlay"></div>
  <div class="video-frame">
    <div class="video-background"></div> <!-- Thêm phần tử video-background -->
    <div class="video-content">
      <!-- Nội dung trong khung video -->
    </div>
  </div>
</div>
</template>

<script>

/**
 * Config vị trí của khung chứa đối tượng cần chụp
 */
// const FRAME_CONFIG = {
//   top: 86,
//   height: 255,
//   px: 8
// }

export default {
  name: "DemoCamera",
  props: {},
  mounted() {
    this.startApp();
  },
  data() {
    return {
      video: null,
      liveView: null,
      hasGetUserMedia: false,
      faceDetector: null,
      runningMode: "IMAGE",
      lastVideoTime: -1,
      children: [],
      warnningText: "",
    };
  },
  methods: {
  },
};
</script>


<style scoped>
.container {
  position: relative;
  width: 100%;
  height: 1000px;
}

.overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
}

.video-frame {
  position: relative;
  width: 100%;
  height: 300px;
  z-index: 2;
  overflow: hidden; /* Ẩn nội dung vượt ra khỏi khung */
}

.video-background {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: #f2f2f2; /* Màu nền của khung video */
  z-index: 1; /* Đặt z-index cho background */
}

.video-content {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
</style>
