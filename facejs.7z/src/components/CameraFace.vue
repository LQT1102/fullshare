<template>
  <div style="display: flex; justify-content: center">
    <div
      style="position: relative;"
      id="liveView-face"
      class="videoView"
      @click="changePhase" 
    >
      <div v-if="warnningText.length" class="text-warning">
        {{ warnningText }}
      </div>
      <video id="webcam-face" autoplay playsinline></video>
      <!-- <div :class="{'shadow-phase-1 shadow' : phase == 1, 'shadow-phase-2 shadow' : phase == 2}"></div> -->
      <img class="shadow" :src="phase == 1 ? '/ekyc-face-bg-1.png' : '/ekyc-face-bg-2.png'" style="position: absolute; width: 100%;height: 100%;left: 0;top: 0; z-index: 1"/>
    </div>
  </div>
</template>

<script>
import { FaceDetector, FilesetResolver } from "@mediapipe/tasks-vision";
export default {
  name: "DemoCameraFace",
  props: {
    onSuccessPhase1: {
      required: true,
      type: Function
    },
    onSuccessPhase2: {
      required: true,
      type: Function
    }
  },
  mounted() {
    this.startApp();
  },
  data() {
    return {
      video: null,
      liveView: null,
      hasGetUserMedia: false,
      faceDetector: null,
      runningMode: "IMAGE",
      lastVideoTime: -1,
      children: [],
      warnningText: "",
      mountedBorder: false,
      phase: 1
    };
  },
  methods: {
    async initializefaceDetector() {
      const vision = await FilesetResolver.forVisionTasks(
        "/vision"
      );
      this.faceDetector = await FaceDetector.createFromOptions(vision, {
        baseOptions: {
          modelAssetPath:
            "/vision/blaze_face_short_range.tflite",
          delegate: "GPU",
        },
        runningMode: this.runningMode,
      });
    },

    getUserMedia() {
      return !!navigator.mediaDevices?.getUserMedia;
    },

    changePhase(){
      alert(this.phase);
      this.phase = this.phase == 1 ? 2 : 1
    },

    async startApp() {
      try {
        this.video = document.getElementById("webcam-face");
        this.video.pause();
        this.liveView = document.getElementById("liveView-face");
        await navigator.mediaDevices.getUserMedia({ video: true });
        await this.initializefaceDetector();

        if (!this.getUserMedia()) {
          console.log("Máy không cho bật camera");
          return;
        }
        if (!this.faceDetector) {
          console.log("chưa tải xong file js");
          return;
        }
        
        // yêu cầu sử dụng webcame
        await this.enableCamera();
        this.video.play();
      } catch (error) {
        alert("Xảy ra lỗi" + JSON.stringify(error))
      }
    },

    async enableCamera() {
      const me = this;
      const stream = await navigator.mediaDevices
        .getUserMedia({
          video: { facingMode: { exact: "user" } },
          audio: false,
        })
       me.video.srcObject = stream;
       me.video.addEventListener("loadeddata", me.predictWebcam);
    },

    async predictWebcam() {
      // if image mode is initialized, create a new classifier with video runningMode
      if (this.runningMode === "IMAGE") {
        this.runningMode = "VIDEO";
        await this.faceDetector.setOptions({ runningMode: "VIDEO" });
      }
      let startTimeMs = performance.now();

      // Detect faces using detectForVideo
      if (this.video.currentTime !== this.lastVideoTime) {
        this.lastVideoTime = this.video.currentTime;
        const detections = this.faceDetector.detectForVideo(
          this.video,
          startTimeMs
        ).detections;
        this.displayVideoDetections(detections);
      }

      // Call this function again to keep predicting when the browser is ready
      window.requestAnimationFrame(this.predictWebcam);
    },
    videoToImageBase64(){
      let videoWidth = this.video.videoWidth;
      let videoHeight = this.video.videoHeight;
      let canvas = document.createElement("canvas");
      canvas.width = videoWidth;
      canvas.height = videoHeight;
      let context = canvas.getContext("2d");
      context.drawImage(this.video,0, 0, videoWidth, videoHeight);
      const src = canvas.toDataURL("image/png");
      return src;
    },
    displayVideoDetections(detections) {
      let checkResult = false;
      if (detections.length > 0) {
        const detection = detections[0];
        const fitLayer = this.checkLayer(detection);
        if (fitLayer) {
          checkResult = this.checkCenter(detection);
        }
      } else {
        this.warnningText = "không có người trong ảnh";
        checkResult = false;
      }

      if(checkResult){
        this.video.pause();
        const base64 = this.videoToImageBase64();
        if(this.phase == 1){
          this.onSuccessPhase1 && this.onSuccessPhase1(base64);
          this.phase = 2;
          this.video.play();
        }else if(this.phase == 2){
          this.onSuccessPhase2 && this.onSuccessPhase2(base64);
        }
      }

      if (!this.mountedBorder) {
        this.mountedBorder = true;
        const shadow = document.querySelector(".shadow");
        shadow.style.display = "block";
        // shadow.style.height = this.video.offsetHeight*0.9 + "px";
        // shadow.style.width = this.video.offsetWidth * 0.5 + "px";
        // shadow.style.left = this.video.offsetWidth * 0.25 + "px";
        // shadow.style.top = this.video.offsetHeight * 0.05 + "px";
      }
    },

    checkLayer(detection) {
      // Nếu diện tích bằng 40 -> 60% thì ok
      if (detection?.boundingBox && this.video) {
        const acreageVideo = this.video.offsetHeight * this.video.offsetWidth;
        const acreageFace =
          detection.boundingBox.height * detection.boundingBox.width;
        if(this.phase === 1){
          if (acreageFace < acreageVideo * 0.1) {
            this.warnningText = "Đưa mặt lại gần";
            return false;
          } else if (acreageFace > acreageVideo * 0.2) {
            this.warnningText = "Đưa mặt ra xa";
            return false;
          }
        }else{
          if (acreageFace < acreageVideo * 0.4) {
            this.warnningText = "Đưa mặt lại gần";
            return false;
          } else if (acreageFace > acreageVideo * 0.6) {
            this.warnningText = "Đưa mặt ra xa";
            return false;
          }
        }
        this.warnningText = "";
        return true;
      }
    },

    // trung tâm khôn mặt phải nằm chính giữa không sai số quá 50% đường chéo màn hình
    checkCenter(detection) {
      if (detection?.boundingBox && this.video) {
        const posFaceX =
          detection.boundingBox.originX + detection.boundingBox.width / 2;
        const posFaceY =
          detection.boundingBox.originY + detection.boundingBox.height / 2;

        const posVideoX = this.video.offsetWidth / 2;
        const posVideoY = this.video.offsetHeight / 2;
        const distanceFace = Math.sqrt(
          (posFaceX - posVideoX) * (posFaceX - posVideoX) +
            (posFaceY - posVideoY) * (posFaceY - posVideoY)
        );
        const distanceVideo = Math.sqrt(
          this.video.offsetWidth * this.video.offsetWidth +
            this.video.offsetHeight * this.video.offsetHeight
        );
        if (distanceFace > distanceVideo * 0.1) {
          this.warnningText = "Đưa mặt về giữa";
          return false;
        }
        this.warnningText = "";
        return true;
      }
    },
  },
};
</script>


<style scoped>
.text-warning {
  position: absolute;
    color: white;
    background: #b54949;
    padding: 8px;
    border-radius: 7px;
    left: calc(50% - 55px);
    z-index: 9999;
}
.shadow {
   display: none;
  /* display: none;
  left: 0;
  right: 0;
  position: absolute;
  z-index: 1;
  top: 0px;
  background-size: contain;
  background-repeat: round;
  background-position-x: center;
  background-position-y: center;
  height: 100%; */
}

.shadow-phase-1{
  background-image: url("/public/ekyc-face-bg-1.png");
}

.shadow-phase-2{
  background-image: url("/public/ekyc-face-bg-2.png");
}

#webcam-face{
  transform: scaleX(-1);
  -webkit-transform: scaleX(-1);
  -moz-transform: scaleX(-1);
  -ms-transform: scaleX(-1);
}

#liveView-face{
  width: 100%;
  overflow-x: hidden;
}
</style>
