# vue2-snippets

# 一、usage🔥
all snippets must prefix "v2"

## 1、vue-html
<table>
    <thead>
    <th>Prefix</th>
    <th>Content</th>
    </thead>
    <tbody>
    <tr>
        <td style='color: orange'>v2Drawer</td>
        <td style='color: orange'>el-drawer...</td>
    </tr>
    <tr>
        <td style='color: orange'>v2Dialog</td>
        <td style='color: orange'>el-dialog...</td>
    </tr>
    <tr>
        <td style='color: orange'>v2Tab</td>
        <td style='color: orange'>el-tab...</td>
    </tr>
    <tr>
        <td style='color: orange'>v2Vfor</td>
        <td style='color: orange'>v-for=" in " :key=""</td>
    </tr>
    <tr>
        <td style='color: orange'>v2PageMark</td>
        <td style='color: orange'>
            <ul>
                <li>页面类型:</li>
                <li>文件名:index:</li>
                <li>菜单路径:</li>
                <li>功能描述:</li>
                <li>创建时间:2023-08-21 18:45:43</li>
            </ul>
        </td>
    </tr>
    </tbody>
</table>


## 2、vue-javascript
<table>
    <thead>
    <th>Prefix</th>
    <th>Content</th>
    </thead>
    <tbody>
    <tr>
        <td style='color: orange'>v2Hlog</td>
        <td style='color: orange'>console.log('online', , 'src/pages/server/customerRepair/customerInfo/vinChange/index.vue-第n行')</td>
    </tr>
    <tr>
        <td style='color: orange'>v2Log</td>
        <td style='color: orange'>console.log(, 'src/pages/server/customerRepair/customerInfo/vinChange/index.vue-第n行')</td>
    </tr>
    <tr>
        <td style='color: orange'>v2Import</td>
        <td style='color: orange'>import  from ''</td>
    </tr>
    <tr>
        <td style='color: orange'>v2Next</td>
        <td style='color: orange'>this.nextTick(() => {})</td>
    </tr>
    <tr>
        <td style='color: orange'>v2VxMap</td>
        <td style='color: orange'>...mapState('', ['']),</td>
    </tr>
    <tr>
        <td style='color: orange'>v2Path</td>
        <td style='color: orange'>~/Documents/GitHub/dms-vue-admin/src/pages/admin/auth/dealerUserManage</td>
    </tr>
    <tr>
        <td style='color: orange'>v2FullPath</td>
        <td style='color: orange'>~/Documents/GitHub/dms-vue-admin/src/pages/admin/auth/dealerUserManage/index.vue</td>
    </tr>
    </tbody>
</table>

## 3、vue
<table>
    <thead>
    <th>Prefix</th>
    <th>Content</th>
    </thead>
    <tbody>
    <tr>
        <td style='color: orange'>v2Template</td>
        <td style='color: orange'>
        export default {
        name: '',components: {},mixins: [],props: {},data() {return {}},computed:{},watch: {},mounted() {},methods: {}};
        </td>
    </tr>
    </tbody>
</table>

## 3、good Fn
<table>
    <thead>
    <th>Prefix</th>
    <th>Content</th>
    </thead>
    <tbody>
    <tr>
        <td style='color: orange'>v2GetUid</td>
        <td style='color: orange'>
            <img src="https://gitee.com/jecson/vue2-snippets/blob/master/assets/uid.png"/>
        </td>
    </tr>
    </tbody>
</table>


