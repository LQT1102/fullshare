function submitSettingsGeneralModal(bodyElement, htmlValue) {
  bodyElement.innerHTML = htmlValue;
  closeModal();
  bodyElement.focus();
  KeySimulation(bodyElement);
}

function onIconSettingsGeneralClick(bodyElement) {
  injectModal().then(function () {
    document.getElementById(VARIABLES.MODAL_INPUT_ID).value =
      bodyElement.innerHTML;

    document
      .getElementById(VARIABLES.MODAL_HEADER_CLOSE_ID)
      .addEventListener('click', function () {
        closeModal();
      });
    document
      .getElementById(VARIABLES.MODAL_BUTTON_CLOSE_ID)
      .addEventListener('click', function () {
        closeModal();
      });

    document
      .getElementById(VARIABLES.MODAL_BUTTON_SUBMIT_ID)
      .addEventListener('click', function () {
        const htmlValue = document.getElementById(VARIABLES.MODAL_INPUT_ID)
          .value;
        submitSettingsGeneralModal(bodyElement, htmlValue);
      });

    addESCListener();

    showModal();
  });
}

function injectIconInSettingsGeneral() {
  if (document.getElementById('gmail-html-form-icon-setting')) {
    return;
  }

  const elements = document.querySelectorAll(
    'div[command="+fontSize"][class="J-Z-M-I J-J5-Ji"]'
  );

  //if there are three element
  if (elements && elements.length >= 3) {
    const element = elements[1];
    const container = window.document.createElement('div');
    container.id = 'gmail-html-form-icon-setting';
    container.className =
      'J-Z-M-I J-J5-Ji gmail-html-form-icon-container-setting';
    container.innerHTML =
      '<img class="inboxsdk__button_iconImg" style="width: 17px" src="' +
      chrome.runtime.getURL('resources/icon.svg') +
      '">';
    container.onclick = function () {
      const bodyElement = document.querySelector(
        'div[class="Am aiL IP Al editable Xp0HJf-LW-avf"]'
      );
      onIconSettingsGeneralClick(bodyElement);
    };
    element.parentNode.insertBefore(container, element.previousSibling);
  } else {
  }
}

function settingsGeneralStart() {
  setInterval(function () {
    if (onSettingsPage() && signatureTextAreaExist()) {
      injectIconInSettingsGeneral();
    }
  }, 2000);
}
