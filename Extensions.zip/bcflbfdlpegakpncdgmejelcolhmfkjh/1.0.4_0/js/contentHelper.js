const VARIABLES = {
  MODAL_CONTAINER_ID: 'gmail-html-modal-container',
  MODAL_INPUT_ID: 'gmail-html-form-textarea',
  MODAL_HEADER_CLOSE_ID: 'gmail-html-form-header-close',
  MODAL_BUTTON_CLOSE_ID: 'gmail-html-form-button-close',
  MODAL_BUTTON_SUBMIT_ID: 'gmail-html-form-button-submit',

  MODAL_ID: 'gmail-html-modal',
  MODAL_CONTENT_ID: 'gmail-html-modal-content',
};

function getModalHtmlTemplates(url) {
  return new Promise(function (resolve, reject) {
    try {
      var xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
          resolve(xhttp.responseText);
        }
      };
      xhttp.open('GET', url, true);
      xhttp.send();
    } catch (err) {
      reject(err);
    }
  });
}

function injectModal() {
  var modalHtmlUrl = chrome.runtime.getURL('resources/modal.html');

  return getModalHtmlTemplates(modalHtmlUrl).then(function (modalHtml) {
    const modal = document.getElementById(VARIABLES.MODAL_CONTAINER_ID);
    if (modal) {
      window.document.body.removeChild(modal);
    }
    const container = window.document.createElement('div');
    container.id = VARIABLES.MODAL_CONTAINER_ID;
    container.innerHTML = modalHtml;
    window.document.body.appendChild(container);
  });
}

function rejectModal() {
  const modal = document.getElementById(VARIABLES.MODAL_CONTAINER_ID);
  if (modal) {
    window.document.body.removeChild(modal);
  }
}

function getElmentOfSignatureTextArea() {
  return document.querySelector(
    'div[g_editable="true"][role="textbox"].Am.aiL.IP.Al.editable'
  );
}

function getElmentOfCreateNewSignature() {
  return document.querySelector('button[class="P5"]');
}

function signatureTextAreaExist() {
  const element = getElmentOfSignatureTextArea();

  return element != null;
}

function onSettingsPage() {
  return location.href.includes('#settings/general');
}

function KeySimulation(textAreaElement) {
  var e = document.createEvent('KeyboardEvent');
  if (e.initKeyboardEvent) {
    // Chrome, IE
    e.initKeyboardEvent(
      'keyup',
      true,
      true,
      document.defaultView,
      'Enter',
      0,
      '',
      false,
      ''
    );
  } else {
    // FireFox
    e.initKeyEvent(
      'keyup',
      true,
      true,
      document.defaultView,
      false,
      false,
      false,
      false,
      13,
      0
    );
  }
  textAreaElement.dispatchEvent(e);
}

function closeModal() {
  rejectModal();
}

function showModal() {
  const modal = document.getElementById(VARIABLES.MODAL_ID);
  modal.classList.add('modal-show');

  const input = document.getElementById(VARIABLES.MODAL_INPUT_ID);
  input.focus();
}

function addESCListener() {
  document.addEventListener('keydown', function (e) {
    if (e.keyCode == 27) {
      closeModal();
    }
  });
}
