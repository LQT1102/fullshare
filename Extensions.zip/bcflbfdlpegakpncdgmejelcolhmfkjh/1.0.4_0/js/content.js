function onLoad() {
  if (onSettingsPage()) {
    settingsGeneralStart();
  }

  window.addEventListener('hashchange', function (event) {
    if (onSettingsPage()) {
      settingsGeneralStart();
    }
  });
}

window.addEventListener('load', onLoad, false);
