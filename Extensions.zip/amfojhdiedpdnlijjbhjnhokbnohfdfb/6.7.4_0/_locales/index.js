
export default message => chrome.i18n.getMessage(message);
