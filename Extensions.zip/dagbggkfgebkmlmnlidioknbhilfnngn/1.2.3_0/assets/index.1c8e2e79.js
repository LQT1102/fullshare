import{r as a,j as t,G as S,H as k,u as L,b as g,J as I,F as D,O as T,C as _,P as y,L as B,B as H,q as A}from"./options.27ebd43e.js";import{F as x}from"./storage.service.687bda0f.js";import{g as i,a as M,b as v}from"./messenger.utils.8edfbef4.js";import{F as q}from"./index.55bcd549.js";import{C as F}from"./CompactLayout.8dfb0962.js";import{F as N}from"./index.96c7f8b5.js";import"./index.bc518402.js";var J={icon:{tag:"svg",attrs:{viewBox:"64 64 896 896",focusable:"false"},children:[{tag:"path",attrs:{d:"M892 772h-80v-80c0-4.4-3.6-8-8-8h-48c-4.4 0-8 3.6-8 8v80h-80c-4.4 0-8 3.6-8 8v48c0 4.4 3.6 8 8 8h80v80c0 4.4 3.6 8 8 8h48c4.4 0 8-3.6 8-8v-80h80c4.4 0 8-3.6 8-8v-48c0-4.4-3.6-8-8-8zM373.5 498.4c-.9-8.7-1.4-17.5-1.4-26.4 0-15.9 1.5-31.4 4.3-46.5.7-3.6-1.2-7.3-4.5-8.8-13.6-6.1-26.1-14.5-36.9-25.1a127.54 127.54 0 01-38.7-95.4c.9-32.1 13.8-62.6 36.3-85.6 24.7-25.3 57.9-39.1 93.2-38.7 31.9.3 62.7 12.6 86 34.4 7.9 7.4 14.7 15.6 20.4 24.4 2 3.1 5.9 4.4 9.3 3.2 17.6-6.1 36.2-10.4 55.3-12.4 5.6-.6 8.8-6.6 6.3-11.6-32.5-64.3-98.9-108.7-175.7-109.9-110.8-1.7-203.2 89.2-203.2 200 0 62.8 28.9 118.8 74.2 155.5-31.8 14.7-61.1 35-86.5 60.4-54.8 54.7-85.8 126.9-87.8 204a8 8 0 008 8.2h56.1c4.3 0 7.9-3.4 8-7.7 1.9-58 25.4-112.3 66.7-153.5 29.4-29.4 65.4-49.8 104.7-59.7 3.8-1.1 6.4-4.8 5.9-8.8zM824 472c0-109.4-87.9-198.3-196.9-200C516.3 270.3 424 361.2 424 472c0 62.8 29 118.8 74.2 155.5a300.95 300.95 0 00-86.4 60.4C357 742.6 326 814.8 324 891.8a8 8 0 008 8.2h56c4.3 0 7.9-3.4 8-7.7 1.9-58 25.4-112.3 66.7-153.5C505.8 695.7 563 672 624 672c110.4 0 200-89.5 200-200zm-109.5 90.5C690.3 586.7 658.2 600 624 600s-66.3-13.3-90.5-37.5a127.26 127.26 0 01-37.5-91.8c.3-32.8 13.4-64.5 36.3-88 24-24.6 56.1-38.3 90.4-38.7 33.9-.3 66.8 12.9 91 36.6 24.8 24.3 38.4 56.8 38.4 91.4-.1 34.2-13.4 66.3-37.6 90.5z"}}]},name:"usergroup-add",theme:"outlined"};const U=J;var C=function(s,h){return t(S,{...k(k({},s),{},{ref:h,icon:U})})};C.displayName="UsergroupAddOutlined";const Q=a.exports.forwardRef(C);const W=[{title:"Load conversation info"},{title:"Calculate messages"},{title:"Load messages"},{title:"Render into readable file"}],X=()=>{const[p,s]=a.exports.useState(""),[h,b]=a.exports.useState(!1),[z,m]=a.exports.useState(!1),[f,O]=a.exports.useState(W),[w,r]=a.exports.useState(-1),{t:u}=L(),l=(e,o=w)=>{f[o].title=e,O([...f])},E=async()=>{try{m(!0),r(0);const e=await x.loadThreadInfo(p);if(!e)throw new Error("You haven't messaged yet.");l("Loaded conversation with "+i(e),0),r(1),l("Total messages: "+e.messages_count,1),r(2);const o=await j();l("Loaded "+o.length+" messages",2),r(3);const n=`
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <title>${i(e)} :: MonokaiToolkit</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
        <style>
          @charset "UTF-8";@import url("https://fonts.googleapis.com/css?family=Manrope:300,400,500,600,700&display=swap&subset=latin-ext");:root {--body-bg-color: #e5ecef;--theme-bg-color: #fff;--settings-icon-hover: #9fa7ac;--developer-color: #f9fafb;--input-bg: #f8f8fa;--input-chat-color: #a2a2a2;--border-color: #eef2f4;--body-font: "Manrope", sans-serif;--body-color: #273346;--settings-icon-color: #c1c7cd;--msg-message: #969eaa;--chat-text-bg: #f1f2f6;--theme-color: #0086ff;--msg-date: #c0c7d2;--button-bg-color: #f0f7ff;--button-color: var(--theme-color);--detail-font-color: #919ca2;--msg-hover-bg: rgba(238, 242, 244, 0.4);--active-conversation-bg: linear-gradient( to right, rgba(238, 242, 244, 0.4) 0%, rgba(238, 242, 244, 0) 100% );--overlay-bg: linear-gradient( to bottom, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, 1) 65%, rgba(255, 255, 255, 1) 100% );--chat-header-bg: linear-gradient( to bottom, rgba(255, 255, 255, 1) 0%, rgba(255, 255, 255, 1) 78%, rgba(255, 255, 255, 0) 100% );}[data-theme=purple] {--theme-color: #9f7aea;--button-color: #9f7aea;--button-bg-color: rgba(159, 122, 234, 0.12);}[data-theme=green] {--theme-color: #38b2ac;--button-color: #38b2ac;--button-bg-color: rgba(56, 178, 171, 0.15);}[data-theme=orange] {--theme-color: #ed8936;--button-color: #ed8936;--button-bg-color: rgba(237, 137, 54, 0.12);}.dark-mode {--body-bg-color: #1d1d1d;--theme-bg-color: #27292d;--border-color: #323336;--body-color: #d1d1d2;--active-conversation-bg: linear-gradient( to right, rgba(47, 50, 56, 0.54), rgba(238, 242, 244, 0) 100% );--msg-hover-bg: rgba(47, 50, 56, 0.54);--chat-text-bg: #383b40;--chat-text-color: #b5b7ba;--msg-date: #626466;--msg-message: var(--msg-date);--overlay-bg: linear-gradient( to bottom, rgba(0, 0, 0, 0) 0%, #27292d 65%, #27292d 100% );--input-bg: #2f3236;--chat-header-bg: linear-gradient( to bottom, #27292d 0%, #27292d 78%, rgba(255, 255, 255, 0) 100% );--settings-icon-color: #7c7e80;--developer-color: var(--border-color);--button-bg-color: #393b40;--button-color: var(--body-color);--input-chat-color: #6f7073;--detail-font-color: var(--input-chat-color);}.blue {background-color: #0086ff;}.purple {background-color: #9f7aea;}.green {background-color: #38b2ac;}.orange {background-color: #ed8936;}* {outline: none;box-sizing: border-box;}img {max-width: 100%;}body {background-color: var(--body-bg-color);font-family: var(--body-font);color: var(--body-color);}html {box-sizing: border-box;-webkit-font-smoothing: antialiased;}.app {display: flex;flex-direction: column;background-color: var(--theme-bg-color);max-width: 1600px;height: 100vh;margin: 0 auto;overflow: hidden;}.header {height: 80px;width: 100%;border-bottom: 1px solid var(--border-color);display: flex;align-items: center;padding: 0 20px;}.wrapper {width: 100%;display: flex;flex-grow: 1;overflow: hidden;}.conversation-area, .detail-area {width: 340px;flex-shrink: 0;}.detail-area {border-left: 1px solid var(--border-color);margin-left: auto;padding: 30px 30px 0 30px;display: flex;flex-direction: column;overflow: auto;}.chat-area {flex-grow: 1;}.search-bar {height: 80px;z-index: 3;position: relative;margin-left: 280px;}.search-bar input {height: 100%;width: 100%;display: block;background-color: transparent;border: none;color: var(--body-color);padding: 0 54px;background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 56.966 56.966' fill='%23c1c7cd'%3e%3cpath d='M55.146 51.887L41.588 37.786A22.926 22.926 0 0046.984 23c0-12.682-10.318-23-23-23s-23 10.318-23 23 10.318 23 23 23c4.761 0 9.298-1.436 13.177-4.162l13.661 14.208c.571.593 1.339.92 2.162.92.779 0 1.518-.297 2.079-.837a3.004 3.004 0 00.083-4.242zM23.984 6c9.374 0 17 7.626 17 17s-7.626 17-17 17-17-7.626-17-17 7.626-17 17-17z'/%3e%3c/svg%3e");background-repeat: no-repeat;background-size: 16px;background-position: 25px 48%;font-family: var(--body-font);font-weight: 600;font-size: 15px;}.search-bar input::placeholder {color: var(--input-chat-color);}.logo {color: var(--theme-color);width: 38px;flex-shrink: 0;}.logo svg {width: 100%;}.user-settings {display: flex;align-items: center;cursor: pointer;margin-left: auto;flex-shrink: 0;}.user-settings > * + * {margin-left: 14px;}.dark-light {width: 22px;height: 22px;color: var(--settings-icon-color);flex-shrink: 0;}.dark-light svg {width: 100%;fill: transparent;transition: 0.5s;}.user-profile {width: 40px;height: 40px;border-radius: 50%;}.settings {color: var(--settings-icon-color);width: 22px;height: 22px;flex-shrink: 0;}.conversation-area {border-right: 1px solid var(--border-color);overflow-y: auto;overflow-x: hidden;display: flex;flex-direction: column;position: relative;}.msg-profile {width: 44px;height: 44px;border-radius: 50%;object-fit: cover;margin-right: 15px;}.msg-profile.group {display: flex;justify-content: center;align-items: center;background-color: var(--border-color);}.msg-profile.group svg {width: 60%;}.msg {display: flex;align-items: center;padding: 20px;cursor: pointer;transition: 0.2s;position: relative;}.msg:hover {background-color: var(--msg-hover-bg);}.msg.active {background: var(--active-conversation-bg);border-left: 4px solid var(--theme-color);}.msg.online:before {content: "";position: absolute;background-color: #23be7e;width: 9px;height: 9px;border-radius: 50%;border: 2px solid var(--theme-bg-color);left: 50px;bottom: 19px;}.msg-username {margin-bottom: 4px;font-weight: 600;font-size: 15px;}.msg-detail {overflow: hidden;}.msg-content {font-weight: 500;font-size: 13px;display: flex;}.msg-message {white-space: nowrap;overflow: hidden;text-overflow: ellipsis;color: var(--msg-message);}.msg-date {font-size: 14px;color: var(--msg-date);margin-left: 3px;}.msg-date:before {content: "\u2022";margin-right: 2px;}.add {position: sticky;bottom: 25px;background-color: var(--theme-color);width: 60px;height: 60px;border: 0;border-radius: 50%;background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='none' stroke='white' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-plus'%3e%3cpath d='M12 5v14M5 12h14'/%3e%3c/svg%3e");background-repeat: no-repeat;background-position: 50%;background-size: 28px;box-shadow: 0 0 16px var(--theme-color);margin: auto auto -55px;flex-shrink: 0;z-index: 1;cursor: pointer;}.overlay {position: sticky;bottom: 0;left: 0;width: 340px;flex-shrink: 0;background: var(--overlay-bg);height: 80px;}.chat-area {display: flex;flex-direction: column;overflow: auto;}.chat-area-header {display: flex;position: sticky;top: 0;left: 0;z-index: 2;width: 100%;align-items: center;justify-content: space-between;padding: 20px;background: var(--chat-header-bg);}.chat-area-profile {width: 32px;border-radius: 50%;object-fit: cover;}.chat-area-title {font-size: 18px;font-weight: 600;}.chat-area-main {flex-grow: 1;}.chat-msg-img {height: 40px;width: 40px;border-radius: 50%;object-fit: cover;}.chat-msg-profile {flex-shrink: 0;margin-top: auto;margin-bottom: -20px;position: relative;}.chat-msg-date {position: absolute;left: calc(100% + 12px);bottom: 0;font-size: 12px;font-weight: 600;color: var(--msg-date);white-space: nowrap;}.chat-msg {display: flex;padding: 0 20px 45px;}.chat-msg-content {margin-left: 12px;max-width: 70%;display: flex;flex-direction: column;align-items: flex-start;}.chat-msg-text {background-color: var(--chat-text-bg);padding: 15px;border-radius: 20px 20px 20px 0;line-height: 1.5;font-size: 14px;font-weight: 500;}.chat-msg-text + .chat-msg-text {margin-top: 10px;}.chat-msg-text {color: var(--chat-text-color);}.owner {flex-direction: row-reverse;}.owner .chat-msg-content {margin-left: 0;margin-right: 12px;align-items: flex-end;}.owner .chat-msg-text {background-color: var(--theme-color);color: #fff;border-radius: 20px 20px 0 20px;}.owner .chat-msg-date {left: auto;right: calc(100% + 12px);}.chat-msg-text img {max-width: 300px;width: 100%;}.chat-area-footer {display: flex;border-top: 1px solid var(--border-color);width: 100%;padding: 10px 20px;align-items: center;background-color: var(--theme-bg-color);position: sticky;bottom: 0;left: 0;}.chat-area-footer svg {color: var(--settings-icon-color);width: 20px;flex-shrink: 0;cursor: pointer;}.chat-area-footer svg:hover {color: var(--settings-icon-hover);}.chat-area-footer svg + svg {margin-left: 12px;}.chat-area-footer input {border: none;color: var(--body-color);background-color: var(--input-bg);padding: 12px;border-radius: 6px;font-size: 15px;margin: 0 12px;width: 100%;}.chat-area-footer input::placeholder {color: var(--input-chat-color);}.detail-area-header {display: flex;flex-direction: column;align-items: center;}.detail-area-header .msg-profile {margin-right: 0;width: 60px;height: 60px;margin-bottom: 15px;}.detail-title {font-size: 18px;font-weight: 600;margin-bottom: 10px;}.detail-subtitle {font-size: 12px;font-weight: 600;color: var(--msg-date);}.detail-button {border: 0;background-color: var(--button-bg-color);padding: 10px 14px;border-radius: 5px;color: var(--button-color);display: flex;align-items: center;justify-content: center;font-size: 14px;flex-grow: 1;font-weight: 500;}.detail-button svg {width: 18px;margin-right: 10px;}.detail-button:last-child {margin-left: 8px;}.detail-buttons {margin-top: 20px;display: flex;width: 100%;}.detail-area input {background-color: transparent;border: none;width: 100%;color: var(--body-color);background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 56.966 56.966' fill='%23c1c7cd'%3e%3cpath d='M55.146 51.887L41.588 37.786A22.926 22.926 0 0046.984 23c0-12.682-10.318-23-23-23s-23 10.318-23 23 10.318 23 23 23c4.761 0 9.298-1.436 13.177-4.162l13.661 14.208c.571.593 1.339.92 2.162.92.779 0 1.518-.297 2.079-.837a3.004 3.004 0 00.083-4.242zM23.984 6c9.374 0 17 7.626 17 17s-7.626 17-17 17-17-7.626-17-17 7.626-17 17-17z'/%3e%3c/svg%3e");background-repeat: no-repeat;background-size: 16px;background-position: 100%;font-family: var(--body-font);font-weight: 600;font-size: 14px;border-bottom: 1px solid var(--border-color);padding: 14px 0;}.detail-area input::placeholder {color: var(--detail-font-color);}.detail-changes {margin-top: 40px;}.detail-change {color: var(--detail-font-color);font-family: var(--body-font);font-weight: 600;font-size: 14px;border-bottom: 1px solid var(--border-color);padding: 14px 0;display: flex;}.detail-change svg {width: 16px;margin-left: auto;}.colors {display: flex;margin-left: auto;}.color {width: 16px;height: 16px;border-radius: 50%;cursor: pointer;}.color.selected {background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' stroke='%23fff' stroke-width='3' fill='none' stroke-linecap='round' stroke-linejoin='round' class='css-i6dzq1' viewBox='0 0 24 24'%3E%3Cpath d='M20 6L9 17l-5-5'/%3E%3C/svg%3E");background-size: 10px;background-position: center;background-repeat: no-repeat;}.color:not(:last-child) {margin-right: 4px;}.detail-photo-title {display: flex;align-items: center;}.detail-photo-title svg {width: 16px;}.detail-photos {margin-top: 30px;text-align: center;}.detail-photo-title {color: var(--detail-font-color);font-weight: 600;font-size: 14px;margin-bottom: 20px;}.detail-photo-title svg {margin-right: 8px;}.detail-photo-grid {display: grid;grid-template-columns: repeat(4, 1fr);grid-column-gap: 6px;grid-row-gap: 6px;grid-template-rows: repeat(3, 60px);}.detail-photo-grid img {height: 100%;width: 100%;object-fit: cover;border-radius: 8px;object-position: center;}.view-more {color: var(--theme-color);font-weight: 600;font-size: 15px;margin: 25px 0;}.follow-me {text-decoration: none;font-size: 14px;margin-left: -30px;display: flex;align-items: center;margin-top: auto;overflow: hidden;color: #9c9cab;padding: 0 20px;height: 52px;flex-shrink: 0;position: relative;justify-content: center;}.follow-me svg {width: 16px;height: 16px;margin-right: 8px;}.follow-text {display: flex;align-items: center;transition: 0.3s;}.follow-me:hover .follow-text {transform: translateY(100%);}.follow-me:hover .developer {top: 0;}.developer {position: absolute;color: var(--detail-font-color);font-weight: 600;left: 0;top: -100%;display: flex;transition: 0.3s;padding: 0 20px;align-items: center;justify-content: center;background-color: var(--developer-color);width: 100%;height: 100%;}.developer img {border-radius: 50%;width: 26px;height: 26px;object-fit: cover;margin-right: 10px;}.dark-mode .search-bar input, .dark-mode .detail-area input {background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 56.966 56.966' fill='%236f7073'%3e%3cpath d='M55.146 51.887L41.588 37.786A22.926 22.926 0 0046.984 23c0-12.682-10.318-23-23-23s-23 10.318-23 23 10.318 23 23 23c4.761 0 9.298-1.436 13.177-4.162l13.661 14.208c.571.593 1.339.92 2.162.92.779 0 1.518-.297 2.079-.837a3.004 3.004 0 00.083-4.242zM23.984 6c9.374 0 17 7.626 17 17s-7.626 17-17 17-17-7.626-17-17 7.626-17 17-17z'/%3e%3c/svg%3e");}.dark-mode .dark-light svg {fill: #ffce45;stroke: #ffce45;}.dark-mode .chat-area-group span {color: #d1d1d2;}.chat-area-group {flex-shrink: 0;display: flex;}.chat-area-group * {border: 2px solid var(--theme-bg-color);}.chat-area-group * + * {margin-left: -5px;}.chat-area-group span {width: 32px;height: 32px;background-color: var(--button-bg-color);color: var(--theme-color);border-radius: 50%;display: flex;justify-content: center;align-items: center;font-size: 14px;font-weight: 500;}@media (max-width: 1120px) {.detail-area {display: none;}}@media (max-width: 780px) {.conversation-area {display: none;}.search-bar {margin-left: 0;flex-grow: 1;}.search-bar input {padding-right: 10px;}}
          .chat-msg-time {font-size: 12px;font-weight: 600;color: var(--msg-date); text-align: center; padding-bottom: 8px;}
        </style>
        
        </head>
        <body>
          <div class="app">
         <div class="header">
          <div class="logo">
           <svg viewBox="0 0 513 513" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
            <path d="M256.025.05C117.67-2.678 3.184 107.038.025 245.383a240.703 240.703 0 0085.333 182.613v73.387c0 5.891 4.776 10.667 10.667 10.667a10.67 10.67 0 005.653-1.621l59.456-37.141a264.142 264.142 0 0094.891 17.429c138.355 2.728 252.841-106.988 256-245.333C508.866 107.038 394.38-2.678 256.025.05z" />
            <path d="M330.518 131.099l-213.825 130.08c-7.387 4.494-5.74 15.711 2.656 17.97l72.009 19.374a9.88 9.88 0 007.703-1.094l32.882-20.003-10.113 37.136a9.88 9.88 0 001.083 7.704l38.561 63.826c4.488 7.427 15.726 5.936 18.003-2.425l65.764-241.49c2.337-8.582-7.092-15.72-14.723-11.078zM266.44 356.177l-24.415-40.411 15.544-57.074c2.336-8.581-7.093-15.719-14.723-11.078l-50.536 30.744-45.592-12.266L319.616 160.91 266.44 356.177z" fill="#fff" /></svg>
          </div>
          <div class="search-bar">
           <input type="text" placeholder="Search..." />
          </div>
          <div class="user-settings">
           <div class="dark-light">
            <svg viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round">
             <path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z" /></svg>
           </div>
           <div class="settings">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
             <circle cx="12" cy="12" r="3" />
             <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z" /></svg>
           </div>
           <img class="user-profile" src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/3364143/download+%281%29.png" alt="" class="account-profile" alt="">
          </div>
         </div>
         <div class="wrapper">
          <div class="chat-area">
           <div class="chat-area-header">
            <div class="chat-area-title">${i(e)}</div>
            <div class="chat-area-group">
              <!--
              <img class="chat-area-profile" src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/3364143/download+%2812%29.png" alt="" />
              <span>+4</span>
              -->
            </div>
           </div>
           <div class="chat-area-main">
              <div class="render-area"></div>
           </div>
           <div class="chat-area-footer">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-video">
             <path d="M23 7l-7 5 7 5V7z" />
             <rect x="1" y="5" width="15" height="14" rx="2" ry="2" /></svg>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-image">
             <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
             <circle cx="8.5" cy="8.5" r="1.5" />
             <path d="M21 15l-5-5L5 21" /></svg>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle">
             <circle cx="12" cy="12" r="10" />
             <path d="M12 8v8M8 12h8" /></svg>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-paperclip">
             <path d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48" /></svg>
            <input type="text" placeholder="Type something here..." />
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-smile">
             <circle cx="12" cy="12" r="10" />
             <path d="M8 14s1.5 2 4 2 4-2 4-2M9 9h.01M15 9h.01" /></svg>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-thumbs-up">
             <path d="M14 9V5a3 3 0 00-3-3l-4 9v11h11.28a2 2 0 002-1.7l1.38-9a2 2 0 00-2-2.3zM7 22H4a2 2 0 01-2-2v-7a2 2 0 012-2h3" /></svg>
           </div>
          </div>
          <div class="detail-area">
           <div class="detail-area-header">
            <div class="msg-profile group">
             <img src=${M(e)}/>
            </div>
            <div class="detail-title">${i(e)}</div>
            <div class="detail-subtitle">${v(e)}</div>
            <div class="detail-buttons">
             <button class="detail-button">
              <svg viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="currentColor" stroke="currentColor" stroke-width="0" stroke-linecap="round" stroke-linejoin="round" class="feather feather-phone">
               <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z" />
              </svg>
              Call Group
             </button>
             <button class="detail-button">
              <svg viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="currentColor" stroke="currentColor" stroke-width="0" stroke-linecap="round" stroke-linejoin="round" class="feather feather-video">
               <path d="M23 7l-7 5 7 5V7z" />
               <rect x="1" y="5" width="15" height="14" rx="2" ry="2" /></svg>
              Video Chat
             </button>
            </div>
           </div>
           <div class="detail-changes">
            <input type="text" placeholder="Search in Conversation">
            <div class="detail-change">
             Change Color
             <div class="colors">
              <div class="color blue selected" data-color="blue"></div>
              <div class="color purple" data-color="purple"></div>
              <div class="color green" data-color="green"></div>
              <div class="color orange" data-color="orange"></div>
             </div>
            </div>
            <div class="detail-change">
             Change Emoji
             <svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-thumbs-up">
              <path d="M14 9V5a3 3 0 00-3-3l-4 9v11h11.28a2 2 0 002-1.7l1.38-9a2 2 0 00-2-2.3zM7 22H4a2 2 0 01-2-2v-7a2 2 0 012-2h3" /></svg>
            </div>
           </div>
           <div class="detail-photos">
            <div class="detail-photo-title">
             <svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-image">
              <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
              <circle cx="8.5" cy="8.5" r="1.5" />
              <path d="M21 15l-5-5L5 21" /></svg>
             Shared photos
            </div>
            <div class="detail-photo-grid">
             <img src="https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=2168&q=80" />
             <img src="https://images.unsplash.com/photo-1516085216930-c93a002a8b01?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=2250&q=80" />
             <img src="https://images.unsplash.com/photo-1458819714733-e5ab3d536722?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=933&q=80" />
             <img src="https://images.unsplash.com/photo-1520013817300-1f4c1cb245ef?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=2287&q=80" />
             <img src="https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=2247&q=80" />
             <img src="https://images.unsplash.com/photo-1559181567-c3190ca9959b?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1300&q=80" />
             <img src="https://images.unsplash.com/photo-1560393464-5c69a73c5770?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1301&q=80" />
             <img src="https://images.unsplash.com/photo-1506619216599-9d16d0903dfd?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=2249&q=80" />
             <img src="https://images.unsplash.com/photo-1481349518771-20055b2a7b24?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=2309&q=80" />
        
             <img src="https://images.unsplash.com/photo-1473170611423-22489201d919?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=2251&q=80" />
             <img src="https://images.unsplash.com/photo-1579613832111-ac7dfcc7723f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=2250&q=80" />
             <img src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=2189&q=80" />
            </div>
            <div class="view-more">View More</div>
           </div>
           <a href="https://monokaitoolkit.com" class="follow-me" target="_blank">
            <span class="follow-text">
             Created by MonokaiToolkit
            </span>
            <span class="developer">
             Visit home
            </span>
           </a>
          </div>
         </div>
        </div>
          <script>
            const thread = {
              id: '${v(e)}',
              name: '${i(e)}',
              picture: '${M(e)}'
            };
            const ownerId = '${x.userId}';
            const messages = ${JSON.stringify(o)}
            const toggleButton = document.querySelector('.dark-light');
            const colors = document.querySelectorAll('.color');
            colors.forEach(color => {
              color.addEventListener('click', e => {
              colors.forEach(c => c.classList.remove('selected'));
              const theme = color.getAttribute('data-color');
              document.body.setAttribute('data-theme', theme);
              color.classList.add('selected');
              });
            });
            toggleButton.addEventListener('click', () => {
              document.body.classList.toggle('dark-mode');
            });
            const mainArea = document.querySelector('.chat-area-main .render-area');
            
            const renderLimit = 20;
            let loaded = 0;
            
            const createMessageElement = (msgSeries) => {
              if (msgSeries.length <= 0) return document.createElement("div");
              const senderId = msgSeries[0]['message_sender']['id'];
              console.log("senderId === ownerId", senderId, ownerId, senderId === ownerId);
              let outerEl = document.createElement('div');
              outerEl.className = 'chat-msg ' + (senderId === ownerId ? 'owner' : 'other');
              let profileDiv = document.createElement('div');
              profileDiv.className = 'chat-msg-profile';
              profileDiv.innerHTML = '<img class="chat-msg-img" src="https://graph.facebook.com/' + senderId + '/picture?type=small&access_token=6628568379|c1e620fa708a1d5696fb991c1bde5662" alt="" /><div class="chat-msg-date">' + new Date(parseInt(msgSeries[msgSeries.length - 1]['timestamp_precise'])).toLocaleString() + '</div>';
              outerEl.appendChild(profileDiv);
              
              const msgContent = document.createElement('div');
              msgContent.className = 'chat-msg-content';
              msgSeries.forEach(m => {
                if (m['message']['text'] && m['message']['text'] !== '') {
                  const msgOuter = document.createElement('div');
                  msgOuter.className = 'chat-msg-text';
                  msgOuter.innerHTML = m['message']['text'];
                  msgContent.appendChild(msgOuter);
                } else if (m['blob_attachments'] && m['blob_attachments'].length > 0) {
                  m['blob_attachments'].forEach(a => {
                    if (a['__typename'] === "MessageImage") {
                      const msgOuter = document.createElement('div');
                      msgOuter.className = 'chat-msg-text';
                      msgOuter.innerHTML = '<img src="' + (a['large_preview'] || a['preview'])['uri'] + '" />';
                      msgContent.appendChild(msgOuter);
                    } else if (a['__typename'] === "MessageVideo") {
                      const msgOuter = document.createElement('div');
                      msgOuter.className = 'chat-msg-text';
                      msgOuter.innerHTML = '<video style="width: 100%;" controls><source src="' + a['playable_url'] + '" type="video/mp4" /></video>';
                      msgContent.appendChild(msgOuter);
                    } else if (a['__typename'] === "MessageAudio") {
                      const msgOuter = document.createElement('div');
                      msgOuter.className = 'chat-msg-text';
                      msgOuter.innerHTML = '<audio style="width: 100%; min-width: 300px" controls><source src="' + a['playable_url'] + '" type="video/mp4" /></audio>';
                      msgContent.appendChild(msgOuter);
                    } else if (a['__typename'] === "MessageAnimatedImage") {
                      const msgOuter = document.createElement('div');
                      msgOuter.className = 'chat-msg-text';
                      msgOuter.innerHTML = '<img src="' + a['animated_image']['uri'] + '" width="' + a['animated_image']['width'] + '" height="' + a['animated_image']['height'] + '" alt="GIF"/>';
                      msgContent.appendChild(msgOuter);
                    }
                  });
                } else if (m['sticker']) {
                  const msgOuter = document.createElement('div');
                  msgOuter.className = 'chat-msg-text';
                  msgOuter.innerHTML = '<img src="' + m['sticker']['url'] + '" width="' + m['sticker']['width'] + '" alt="Sticker"/>';
                  msgContent.appendChild(msgOuter);
                }
              });
              outerEl.appendChild(msgContent);
              return outerEl;
            }
            
            const renderMessages = (index = 0) => {
              const startPointer = messages.length - index - renderLimit;
              const part = messages.slice(startPointer >= 0 ? startPointer : 0, messages.length - index);
              loaded += part.length;
              let msgSeries = [];
              let preSender = '';
              let lastSenderMsgTime = 0;
              const newDiv = document.createElement('div');
              part.forEach((msg, i) => {
                console.log(msg);
                const senderId = msg['message_sender']['id'];
                const timeDiff = parseInt(msg['timestamp_precise']) - lastSenderMsgTime;
                if (preSender === '') preSender = senderId;
                if (senderId !== preSender || timeDiff > 15*60*1000 || i >= part.length - 1) {
                  if (senderId !== preSender && timeDiff > 15*60*1000) {
                    console.log('===> render time');
                    renderedTime = true;
                    const timeEl = document.createElement('div');
                    timeEl.className = 'chat-msg-time';
                    timeEl.innerText = new Date(parseInt(msg['timestamp_precise'])).toLocaleString();
                    newDiv.appendChild(timeEl);
                  }
                  // render and clear
                  let render = () => {
                    const el = createMessageElement(msgSeries);
                    newDiv.appendChild(el);
                  };
                  render();
                  msgSeries = [msg];
                  if (i >= part.length - 1) render();
                } else {
                  msgSeries.push(msg);
                }
                preSender = msg['message_sender']['id'];
                lastSenderMsgTime = parseInt(msg['timestamp_precise']);
              })
              mainArea.prepend(newDiv);
            }
            renderMessages(0);
            document.querySelector('.chat-area').onscroll = (e) => {
              if (e.target.scrollTop === 0) {
                renderMessages(loaded);
                e.target.scrollTop = 30;
              }
            }
          <\/script>
        </body>
      </html>
    `,d=new Blob([n],{type:"text/html"}),c=URL.createObjectURL(d);chrome.downloads.download({url:c,filename:v(e)+"_"+new Date().getTime()+".html"}).then(()=>{console.log("Download started...")}),r(-1),m(!1)}catch(e){m(!1),r(-1),A.error(e.message)}},j=async()=>{let e=[],o=new Date().getTime()+5e3;const n=async()=>{const d=await x.loadThreadMessages(p,100,o),c=d.nodes;o=c[0].timestamp_precise-1,e.unshift(...c),console.log(e),l("Loaded "+e.length+" messages",2),d.page_info.has_previous_page&&await n()};return await n(),e};return g("div",{className:"download-inbox",children:[t(I,{routes:[{key:"download-inbox",icon:t(D,{icon:T}),label:u("f.download-inbox.name"),url:""}],title:u("f.download-inbox.name"),description:u("f.download-inbox.desc")}),g(F,{children:[g(_,{children:[g("p",{children:["Please input ID of the conversation you want to download. Or you can manually choose from the friend list using"," ",t(Q,{})," button."]}),t("div",{className:"input-id-group",children:t(N,{onChange:e=>s(e),hideSelectMyId:!0})}),t("div",{className:"mt-4",children:t(y,{children:f.map((e,o)=>t(y.Item,{dot:w===o?t(B,{spin:!0}):void 0,children:e.title},o))})}),t("div",{children:t(H,{size:"small",disabled:z,block:!0,type:"primary",onClick:E,children:"Start Download"})})]}),t(q,{visible:h,onPicked:e=>{s(e),b(!1)},onCancel:()=>{b(!1)},selectedFriends:[]})]})]})};export{X as default};
