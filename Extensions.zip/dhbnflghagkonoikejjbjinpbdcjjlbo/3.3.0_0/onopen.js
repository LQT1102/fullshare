if (chrome && chrome.browserAction){
    var baseUrl = "https://www.fax.plus"
    var appUrl = "https://app.fax.plus"
    chrome.runtime.onInstalled.addListener(function() {
		chrome.tabs.create({ url: baseUrl + "/extension-installed/" });
    });

    chrome.runtime.setUninstallURL(baseUrl + "/extension-uninstalled/");

    // open a new page on left clicking on the extension itself
    chrome.browserAction.onClicked.addListener(function() {
		chrome.tabs.create({ url: appUrl + "/send-fax" });
	});

    chrome.contextMenus.create({
        "id": "send_fax",
        "title": chrome.i18n.getMessage("sendFax"),
        "contexts": ["browser_action"]
    });

    chrome.contextMenus.create({
        "id": "view_archive",
        "title": chrome.i18n.getMessage("viewArchive"),
        "contexts": ["browser_action"]
    });

    chrome.contextMenus.create({
        "id": "add_credit",
        "title": chrome.i18n.getMessage("addCredit"),
        "contexts": ["browser_action"]
    });

    chrome.contextMenus.create({
        "id": "help_center",
        "title": chrome.i18n.getMessage("helpCenter"),
        "contexts": ["browser_action"]
    });

	chrome.contextMenus.onClicked.addListener(function(info)
	{
	    urls = {
	        send_fax: appUrl + "/send-fax",
	        view_archive: appUrl + "/archive/inbox",
	        add_credit: appUrl + "/profile/plan_billing?direct_open_modal=credit",
	        help_center: baseUrl + "/help"
	    };
	    chrome.tabs.create({url: urls[info.menuItemId]});
	});
}